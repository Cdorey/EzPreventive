﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using WalkingTec.Mvvm.Mvc;
using EzNutrition.Model;
using EzNutrition.ViewModel.Nutrition.FoodNutrientValueVMs;
using EzNutrition.Model.Nutrition;


namespace EzNutrition.Nutrition.Controllers
{
    [AuthorizeJwtWithCookie]
    public partial class FoodNutrientValueController : BaseApiController
    {
            
    }
}


