﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.FoodNutrientValueVMs
{
    public partial class FoodNutrientValueTemplateVM : BaseTemplateVM
    {
        
	    protected override void InitVM()
        {
            
        }

    }

    public class FoodNutrientValueImportVM : BaseImportVM<FoodNutrientValueTemplateVM, FoodNutrientValue>
    {
        //import

    }

}