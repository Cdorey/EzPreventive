﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.FoodNutrientValueVMs
{
    public partial class FoodNutrientValueListVM : BasePagedListVM<FoodNutrientValue_View, FoodNutrientValueSearcher>
    {
        
        protected override IEnumerable<IGridColumn<FoodNutrientValue_View>> InitGridHeader()
        {
            return new List<GridColumn<FoodNutrientValue_View>>{
                
                this.MakeGridHeaderAction(width: 200).SetHide(true)
            };
        }

        
        public override IOrderedQueryable<FoodNutrientValue_View> GetSearchQuery()
        {
            var query = DC.Set<FoodNutrientValue>()
                                .Select(x => new FoodNutrientValue_View
                {
				    ID = x.ID,
                                    })
                .OrderBy(x => x.ID);
            return query;
        }

    }
    public class FoodNutrientValue_View: FoodNutrientValue
    {
        
    }

}