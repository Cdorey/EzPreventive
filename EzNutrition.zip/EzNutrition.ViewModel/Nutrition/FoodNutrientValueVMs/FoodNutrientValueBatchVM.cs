﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using Microsoft.EntityFrameworkCore;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.FoodNutrientValueVMs
{
    public partial class FoodNutrientValueBatchVM : BaseBatchVM<FoodNutrientValue, FoodNutrientValue_BatchEdit>
    {
        public FoodNutrientValueBatchVM()
        {
            ListVM = new FoodNutrientValueListVM();
            LinkedVM = new FoodNutrientValue_BatchEdit();
        }

        public override bool DoBatchEdit()
        {
            
            return base.DoBatchEdit();
        }
    }

	/// <summary>
    /// Class to define batch edit fields
    /// </summary>
    public class FoodNutrientValue_BatchEdit : BaseVM
    {

        
        protected override void InitVM()
        {
           
        }
    }

}