﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using Microsoft.EntityFrameworkCore;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.NutrientVMs
{
    public partial class NutrientBatchVM : BaseBatchVM<Nutrient, Nutrient_BatchEdit>
    {
        public NutrientBatchVM()
        {
            ListVM = new NutrientListVM();
            LinkedVM = new Nutrient_BatchEdit();
        }

        public override bool DoBatchEdit()
        {
            
            return base.DoBatchEdit();
        }
    }

	/// <summary>
    /// Class to define batch edit fields
    /// </summary>
    public class Nutrient_BatchEdit : BaseVM
    {

        
        protected override void InitVM()
        {
           
        }
    }

}