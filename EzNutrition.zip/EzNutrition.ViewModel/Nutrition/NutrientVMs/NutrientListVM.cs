﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.NutrientVMs
{
    public partial class NutrientListVM : BasePagedListVM<Nutrient_View, NutrientSearcher>
    {
        
        protected override IEnumerable<IGridColumn<Nutrient_View>> InitGridHeader()
        {
            return new List<GridColumn<Nutrient_View>>{
                
                this.MakeGridHeaderAction(width: 200).SetHide(true)
            };
        }

        
        public override IOrderedQueryable<Nutrient_View> GetSearchQuery()
        {
            var query = DC.Set<Nutrient>()
                                .Select(x => new Nutrient_View
                {
				    ID = x.ID,
                                    })
                .OrderBy(x => x.ID);
            return query;
        }

    }
    public class Nutrient_View: Nutrient
    {
        
    }

}