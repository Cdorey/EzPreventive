﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using Microsoft.EntityFrameworkCore;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.FoodVMs
{
    public partial class FoodBatchVM : BaseBatchVM<Food, Food_BatchEdit>
    {
        public FoodBatchVM()
        {
            ListVM = new FoodListVM();
            LinkedVM = new Food_BatchEdit();
        }

        public override bool DoBatchEdit()
        {
            
            return base.DoBatchEdit();
        }
    }

	/// <summary>
    /// Class to define batch edit fields
    /// </summary>
    public class Food_BatchEdit : BaseVM
    {

        
        protected override void InitVM()
        {
           
        }
    }

}