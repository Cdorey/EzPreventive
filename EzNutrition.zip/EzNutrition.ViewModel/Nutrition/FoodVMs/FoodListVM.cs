﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using EzNutrition.Model.Nutrition;
using EzNutrition.Model;

namespace EzNutrition.ViewModel.Nutrition.FoodVMs
{
    public partial class FoodListVM : BasePagedListVM<Food_View, FoodSearcher>
    {
        
        protected override IEnumerable<IGridColumn<Food_View>> InitGridHeader()
        {
            return new List<GridColumn<Food_View>>{
                
                this.MakeGridHeaderAction(width: 200).SetHide(true)
            };
        }

        
        public override IOrderedQueryable<Food_View> GetSearchQuery()
        {
            var query = DC.Set<Food>()
                                .Select(x => new Food_View
                {
				    ID = x.ID,
                                    })
                .OrderBy(x => x.ID);
            return query;
        }

    }
    public class Food_View: Food
    {
        
    }

}