﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Extensions;
using Microsoft.EntityFrameworkCore;

using EzNutrition.Model.Nutrition;
using EzNutrition.Model;
namespace EzNutrition.ViewModel.Nutrition.FoodVMs
{
    public partial class FoodVM : BaseCRUDVM<Food>
    {
        
        public FoodVM()
        {
            
        }

        protected override void InitVM()
        {
            
        }

        public override DuplicatedInfo<Food> SetDuplicatedCheck()
        {
            return null;

        }

        public override async Task DoAddAsync()        
        {
            
            await base.DoAddAsync();

        }

        public override async Task DoEditAsync(bool updateAllFields = false)
        {
            
            await base.DoEditAsync();

        }

        public override async Task DoDeleteAsync()
        {
            await base.DoDeleteAsync();

        }
    }
}
