﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EzNutrition.Model
{

    public class RefDicNameAttribute : Attribute
    {
        public string Name { get; set; }
    }
}