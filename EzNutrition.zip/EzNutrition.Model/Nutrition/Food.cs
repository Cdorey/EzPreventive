﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WalkingTec.Mvvm.Core;
using System.Text.Json.Serialization;
using EzNutrition.Model;
using EzNutrition.Model.Nutrition;

namespace EzNutrition.Model.Nutrition
{
    /// <summary>
    /// 食材
    /// </summary>
	[Table("Foods")]

    [Display(Name = "_Model.Food")]
    public class Food : BasePoco,IPersistPoco
    {
        [Display(Name = "_Model._Food._FriendlyName")]
        [StringLength(64, ErrorMessage = "Validate.{0}stringmax{1}")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public string FriendlyName { get; set; }
        [Display(Name = "_Model._Food._FriendlyCode")]
        [StringLength(64, ErrorMessage = "Validate.{0}stringmax{1}")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public string FriendlyCode { get; set; }
        [Display(Name = "_Model._Food._Cite")]
        public string Cite { get; set; }
        [Display(Name = "_Model._Food._Details")]
        public string Details { get; set; }
        [Display(Name = "_Model._Food._FoodId")]
        [Comment("FoodNutrientValue")]
        public List<FoodFoodNutrientValue_MT_Wtm> FoodFoodNutrientValue_MT_Wtms { get; set; }
        [Display(Name = "_Model._Food._IsValid")]
        [Comment("是否有效")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public bool IsValid { get; set; } = true;

	}

}
