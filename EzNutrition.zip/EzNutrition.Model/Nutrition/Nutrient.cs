﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WalkingTec.Mvvm.Core;
using System.Text.Json.Serialization;
using EzNutrition.Model;
using EzNutrition.Model.Nutrition;

namespace EzNutrition.Model.Nutrition
{
    /// <summary>
    /// Nutrient
    /// </summary>
	[Table("Nutrients")]

    [Display(Name = "_Model.Nutrient")]
    public class Nutrient : BasePoco,IPersistPoco
    {
        [Display(Name = "_Model._Nutrient._FriendlyName")]
        [StringLength(64, ErrorMessage = "Validate.{0}stringmax{1}")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public string FriendlyName { get; set; }
        [Display(Name = "_Model._Nutrient._DefaultMeasureUnit")]
        [StringLength(64, ErrorMessage = "Validate.{0}stringmax{1}")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public string DefaultMeasureUnit { get; set; }
        [Display(Name = "_Model._Nutrient._Details")]
        public string Details { get; set; }
        [Display(Name = "_Model._Nutrient._NutrientId")]
        [Comment("FoodNutrientValue")]
        public List<FoodNutrientValueNutrient_MT_Wtm> FoodNutrientValueNutrient_MT_Wtms { get; set; }
        [Display(Name = "_Model._Nutrient._IsValid")]
        [Comment("是否有效")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public bool IsValid { get; set; } = true;

	}

}
