﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WalkingTec.Mvvm.Core;
using System.Text.Json.Serialization;
using EzNutrition.Model;
using EzNutrition.Model.Nutrition;

namespace EzNutrition.Model.Nutrition
{
    /// <summary>
    /// FoodNutrientValue
    /// </summary>
	[Table("FoodNutrientValues")]

    [Display(Name = "_Model.FoodNutrientValue")]
    public class FoodNutrientValue : TopBasePoco
    {
        [Display(Name = "_Model._FoodNutrientValue._FoodId")]
        public List<FoodFoodNutrientValue_MT_Wtm> FoodFoodNutrientValue_MT_Wtms { get; set; }
        [Display(Name = "_Model._FoodNutrientValue._NutrientId")]
        public List<FoodNutrientValueNutrient_MT_Wtm> FoodNutrientValueNutrient_MT_Wtms { get; set; }
        [Display(Name = "_Model._FoodNutrientValue._Value")]
        [Required(ErrorMessage = "Validate.{0}required")]
        public double? Value { get; set; }
        [Display(Name = "_Model._FoodNutrientValue._MeasureUnit")]
        [StringLength(64, ErrorMessage = "Validate.{0}stringmax{1}")]
        public string MeasureUnit { get; set; }
        [Display(Name = "_Model._FoodNutrientValue._Details")]
        public string Details { get; set; }

	}

}
