﻿using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using WalkingTec.Mvvm.Core;
using WalkingTec.Mvvm.Core.Attributes;
using EzNutrition.Model.Nutrition;

namespace EzNutrition.Model
{
    public class _PlaceHolder_
    {
    }
    [MiddleTable]
    public class FoodFoodNutrientValue_MT_Wtm : BasePoco
    {
        [Display(Name = "_Model.Food")]
        public Food Food { get; set; }
        [Display(Name = "_Model.Food")]
        [Comment("食材")]
        public Guid? FoodId { get; set; }
        [Display(Name = "_Model.FoodNutrientValue")]
        public FoodNutrientValue FoodNutrientValue { get; set; }
        [Display(Name = "_Model.FoodNutrientValue")]
        public Guid? FoodNutrientValueId { get; set; }
    }
    [MiddleTable]
    public class FoodNutrientValueNutrient_MT_Wtm : BasePoco
    {
        [Display(Name = "_Model.Nutrient")]
        public Nutrient Nutrient { get; set; }
        [Display(Name = "_Model.Nutrient")]
        public Guid? NutrientId { get; set; }
        [Display(Name = "_Model.FoodNutrientValue")]
        public FoodNutrientValue FoodNutrientValue { get; set; }
        [Display(Name = "_Model.FoodNutrientValue")]
        public Guid? FoodNutrientValueId { get; set; }
    }
}
